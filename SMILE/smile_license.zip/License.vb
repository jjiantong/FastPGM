REM License issued by BayesFusion Licensing Server
REM This code must be executed before any other SMILE.NET object is created 
Dim smileLicense As New Smile.License(
	"SMILE LICENSE 662c9732 39df2444 a8298dde " +
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED " +
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, " +
	"AS DEFINED IN THE BAYESFUSION ACADEMIC " +
	"SOFTWARE LICENSING AGREEMENT. " +
	"Serial #: 3hkbln4eicvc2wgyvzbxr5vjp " +
	"Issued for: Jiang Jiantong (jjiantong@gmail.com) " +
	"Academic institution: The University of Western Australia " +
	"Valid until: 2023-06-26 " +
	"Issued by BayesFusion activation server",
	{
	&H68,&H2c,&H6f,&H54,&Hb6,&H64,&He1,&H08,&H06,&Hdd,&H4c,&H64,&H01,&H88,&H62,&Ha2,
	&He1,&H0e,&Hbe,&H01,&H80,&Hef,&Hf1,&Hf8,&H46,&H16,&H15,&He8,&Hb3,&Hcf,&H7c,&Hae,
	&H6d,&Hc5,&H0e,&H40,&Hfb,&H01,&H7a,&He7,&He5,&H63,&Hc5,&H93,&H66,&H66,&H8e,&Hd2,
	&H93,&Hf9,&H0a,&Hbe,&H95,&Heb,&Hdf,&Hc2,&H3c,&H38,&H14,&Hb8,&H4b,&Hea,&H26,&Hf0
	})

# License issued by BayesFusion Licensing Server
#
# This code must be executed before any other rSMILE object is created 
rSMILE::License(paste(
	"SMILE LICENSE 662c9732 39df2444 a8298dde ",
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED ",
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, ",
	"AS DEFINED IN THE BAYESFUSION ACADEMIC ",
	"SOFTWARE LICENSING AGREEMENT. ",
	"Serial #: 3hkbln4eicvc2wgyvzbxr5vjp ",
	"Issued for: Jiang Jiantong (jjiantong@gmail.com) ",
	"Academic institution: The University of Western Australia ",
	"Valid until: 2023-06-26 ",
	"Issued by BayesFusion activation server",
	sep=""),as.integer(c(
	104,44,111,84,-74,100,-31,8,6,-35,76,100,1,-120,98,-94,
	-31,14,-66,1,-128,-17,-15,-8,70,22,21,-24,-77,-49,124,-82,
	109,-59,14,64,-5,1,122,-25,-27,99,-59,-109,102,102,-114,-46,
	-109,-7,10,-66,-107,-21,-33,-62,60,56,20,-72,75,-22,38,-16))
)

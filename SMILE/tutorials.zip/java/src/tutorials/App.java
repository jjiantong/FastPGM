package tutorials;

public class App {

    public static void main(String[] args) {
        System.out.println("Insert your license key below.");
        // new smile.License(...);

        Tutorial1.run();
        Tutorial2.run();
        Tutorial3.run();
        Tutorial4.run();
        Tutorial5.run();
        Tutorial6.run();
        Tutorial7.run();
        Tutorial8.run();
    }
}

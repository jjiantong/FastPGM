Welcome to SMILE and SMILE Wrapper tutorials.

For each language/environment, you'll need your SMILE license key. If you 
don't have the license key, you can obtain a trial or an academic key from
our download website at https://download.bayesfusion.com.
Please note that the option to create the license key is shown after you log in.

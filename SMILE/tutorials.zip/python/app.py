import pysmile
import pysmile_license

import tutorial1 as t1
import tutorial2 as t2
import tutorial3 as t3
import tutorial4 as t4
import tutorial5 as t5
import tutorial6 as t6
import tutorial7 as t7
import tutorial8 as t8


t1.Tutorial1()
t2.Tutorial2()
t3.Tutorial3()
t4.Tutorial4()
t5.Tutorial5()
t6.Tutorial6()
t7.Tutorial7()
t8.Tutorial8()
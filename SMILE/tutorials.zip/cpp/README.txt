This directory contains the C++ source code for the SMILE tutorials.

To build your program from the tutorial source, you must copy your 
"smile_license.h" file into this directory. 

SMILE header files should be copied to the "smile" subdirectory.

This directory contains source code for the SMILE.NET tutorial.

You must add your SMILE license key to Program.cs, otherwise
the tutorial will not run.

The code requires the reference to smilenet.dll to be set.


﻿using System;

namespace SmileNetTutorial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insert your SMILE License Key here.");
            // new Smile.License(...);

            Tutorial1.Run();
            Tutorial2.Run();
            Tutorial3.Run();
            Tutorial4.Run();
            Tutorial5.Run();
            Tutorial6.Run();
            Tutorial7.Run();
            Tutorial8.Run();
        }
    }
}
